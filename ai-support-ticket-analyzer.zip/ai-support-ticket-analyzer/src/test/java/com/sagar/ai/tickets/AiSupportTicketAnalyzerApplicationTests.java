package com.sagar.ai.tickets;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AiSupportTicketAnalyzerApplicationTests {

	@Test
	void contextLoads() {
	}

}
