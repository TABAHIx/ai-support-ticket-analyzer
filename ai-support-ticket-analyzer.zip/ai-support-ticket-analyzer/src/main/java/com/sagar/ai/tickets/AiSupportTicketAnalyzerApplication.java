package com.sagar.ai.tickets;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AiSupportTicketAnalyzerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AiSupportTicketAnalyzerApplication.class, args);
	}

}
